package com.senaidev.saraiva;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaraivaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SaraivaApplication.class, args);
	}

}
