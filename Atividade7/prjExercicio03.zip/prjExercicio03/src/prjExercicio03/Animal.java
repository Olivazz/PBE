package prjExercicio03;

public class Animal {
	// Atributos
	private String nome;
	private int idade;
	private String raca;
	
	
	// Construtores
	public Animal() {
		
	}
	
	public Animal(String nome, int idade, String raca) {
		this.nome = nome;
		this.idade = idade;
		this.raca = raca;
	}
	
	
	// Método
	public void fazerSom() {
		System.out.println(nome + " fez um som.");
	}
}
