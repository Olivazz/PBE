package prjExercicio03;

public class Baleia extends Animal{
	// Método da Subclasse
	public void nadar() {
		System.out.println("A baleia está nadando.");
	}
}
