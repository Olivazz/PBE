package prjExercicio03;

public class Leao extends Animal{
	// Método da Subclasse
	public void cacar() {
		System.out.println("O leão está caçando.");
	}
}
