package prjExercicio01;

public class Carro {
	// Atributos
	private String marca;
	private String modelo;
	private String placa;
	private int ano;
	
	
	// Construtores
	public Carro() {
		
	}
	
	public Carro(String marca, String modelo, String placa, int ano) {
		this.marca = marca;
		this.modelo = modelo;
		this.placa = placa;
		this.ano = ano;
	}
	
	// Métodos
	public void exibirInfo() {
		System.out.println("Marca: " + marca);
		System.out.println("Modelo: " + modelo);
		System.out.println("Placa: " + placa);
		System.out.println("Ano: " + ano + "\n");
	}
}
