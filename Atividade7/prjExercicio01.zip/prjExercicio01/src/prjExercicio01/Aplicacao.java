package prjExercicio01;

public class Aplicacao {

	public static void main(String[] args) {
		// Criação dos objetos
		Carro carro01 = new Carro("Toyota", "Hilux", "ABC1B34", 2014);
		Carro carro02 = new Carro("Hyundai", "HB20", "XYZ2Y68", 2015);
		
		// Exibir as informações dos objetos
		carro01.exibirInfo();
		carro02.exibirInfo();
	}

}
