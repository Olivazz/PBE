package prjExercicio04;

public class Caminhao extends Veiculo{
	// Métodos da Subclasse
	@Override
	public void acelerar() {
		System.out.println("O caminhão está acelerando.");
	}
	@Override
	public void frear() {
		System.out.println("O caminhão está freando.");
	}
}
