package prjExercicio04;

public class Moto extends Veiculo{
	// Métodos da Subclasse
	@Override
	public void acelerar() {
		System.out.println("A moto está acelerando.");
	}
	@Override
	public void frear() {
		System.out.println("A moto está freando.");
	}
}
