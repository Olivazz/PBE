package prjExercicio04;

public class Veiculo {
	// Atributos
	private String marca;
	private String modelo;
	private int velocidade;
	
	
	// Construtores 
	public Veiculo() {
		
	}
	
	public Veiculo(String marca, String modelo, int velocidade) {
		this.marca = marca;
		this.modelo = modelo;
		this.velocidade = velocidade;
	}
	
	
	// Métodos
	public void acelerar() {
		velocidade+=10;
		System.out.println("Veículo Acelerando.");
	}
	
	public void frear() {
		velocidade-=10;
		System.out.println("Veículo Freando.");
	}
}
