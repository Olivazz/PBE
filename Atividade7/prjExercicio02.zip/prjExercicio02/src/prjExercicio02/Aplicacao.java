package prjExercicio02;

public class Aplicacao {

	public static void main(String[] args) {
		// Criação dos objetos
		Livro livro01 = new Livro("Dom Quixote de la Mancha", "Miguel de Cervantes", 1033, 65.00);
		Livro livro02 = new Livro("O Pequeno Príncipe", "Antoine de Saint-Exupéry", 96, 50.00);
		Livro livro03 = new Livro("Sherlock Holmes", "Árthur Conan Doyle", 1808, 83.00);
		
		// Exibir as informações dos objetos
		livro01.exibirInfo();
		livro02.exibirInfo();
		livro03.exibirInfo();
		
		// Aplica um desconto de 15 reais nos livros
		livro01.aplicarDesconto(15);
		livro02.aplicarDesconto(15);
		livro03.aplicarDesconto(15);
		
		// Exibir as informações dos objetos
		livro01.exibirInfo();
		livro02.exibirInfo();
		livro03.exibirInfo();
	}

}
