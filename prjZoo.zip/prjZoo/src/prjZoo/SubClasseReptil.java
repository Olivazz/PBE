package prjZoo;

public class SubClasseReptil extends ClasseAnimal {
	
	//Metodos da Subclasse
	
	public void metodoTrocarPele() {
		System.out.println(this.atributoNome + " está trocando de pele!");
	}
	public void metodoRasteijar() {
		System.out.println(this.atributoNome + " está rasteijando!");
	}
	
	@Override
	public void metodoEmitirSom() {
		System.out.println("Pshiiiish");
	}
	
}
