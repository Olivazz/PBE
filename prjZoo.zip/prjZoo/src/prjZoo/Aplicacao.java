package prjZoo;

public class Aplicacao {

	public static void main(String[] args) {
		ClasseAnimal elefante = new ClasseAnimal();
		elefante.setNome("Dumbo");
		elefante.setPeso(100);
		
		ClasseAnimal girafa = new ClasseAnimal("Github","Russa","Femea",90);
		
		SubClasseCarnivora leao = new SubClasseCarnivora();
		leao.atributoNome = "Leaondro";
		leao.atributoRaca = "Australeandro";
		leao.atributoSexo = "Femea";
		leao.atributoPeso = 123;
		
		elefante.exibirInfo();
		
		elefante.metodoComer(50);
		
		elefante.exibirInfo();
		
		girafa.exibirInfo();
		
		elefante.metodoEmitirSom();
		
		girafa.metodoEmitirSom();
		
		leao.metodoEmitirSom();
		
	}

}