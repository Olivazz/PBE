package prjZoo;

public class SubClasseCarnivora extends ClasseAnimal {
	//Metodos da Subclasse
	public void metodoCacar() {
		System.out.println(this.atributoNome + " está caçando");
	}
	@Override
	public void metodoEmitirSom() {
		System.out.println("RUAARRR");
	}
}
