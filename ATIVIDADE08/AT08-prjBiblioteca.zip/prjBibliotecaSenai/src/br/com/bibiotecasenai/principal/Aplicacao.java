package br.com.bibiotecasenai.principal;

import br.com.bibiotecasenai.usuarios.Bibliotecario;
import br.com.bibiotecasenai.usuarios.Usuario;

public class Aplicacao {

	public static void main(String[] args) {
		
		Usuario usuario01 = new Usuario();
		usuario01.setLivrosEmprestados(10);
		
		Usuario usuario02 = new Usuario();
		usuario02.setLivrosEmprestados(8);
		
		Bibliotecario bibliotecario = new Bibliotecario();
		
	}
}
