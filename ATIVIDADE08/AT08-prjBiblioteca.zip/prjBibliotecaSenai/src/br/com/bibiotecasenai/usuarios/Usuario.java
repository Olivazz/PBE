package br.com.bibiotecasenai.usuarios;

public class Usuario extends Pessoas{
	
	//Atributos
	
	private String cpf;
	private int livrosEmprestados;
	
	//Getters e Setters
	
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public int getLivrosEmprestados() {
		return livrosEmprestados;
	}
	public void setLivrosEmprestados(int livrosEmprestados) {
		this.livrosEmprestados = livrosEmprestados;
	}
	
}
