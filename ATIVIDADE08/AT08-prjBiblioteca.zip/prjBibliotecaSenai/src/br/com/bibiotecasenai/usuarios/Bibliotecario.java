package br.com.bibiotecasenai.usuarios;

public class Bibliotecario extends Pessoas{
	
	//Atributos
	
	private String matricula;
	private String nome;
	
	//Metodos
	
	public void realizarEmprestimo() {
		System.out.println("O seu Emprestimo foi realizado");
	}
	
	public void devolverLivro() {
		System.out.println(this.nome + "devolveu o livro");
	}

}
